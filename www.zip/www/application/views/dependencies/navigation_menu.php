			<div id="sidenav">
				<ul>
					<li>
						<a href="<?=site_url("customers"); ?>">Customer Information</a>
					</li>
					<li>
						<a href="<?=site_url("enrollments");?>">Enrollments</a>
					</li>
					<li>
						<a href="<?=site_url("teachers");?>">Teachers</a>
					</li>
					<li>
						<a href="<?=site_url("gale");?>">Gale</a>
					</li>
					<li>
						<a href="<?=site_url("select_report");?>">Select Report</a>
					</li>
					<li>
						<a href="<?=site_url("customreport");?>">Custom Reports</a>
					</li>
					
					<!-- This runs via cron job, not necessary to have direct access<li>
						<a href="_mil_enrollments.php">Biweekly MIL Enrollments</a>
					</li> -->
				</ul>
			</div>
