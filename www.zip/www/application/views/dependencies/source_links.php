		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript" src="<?=base_url();?>assets/javascript/jquery-ui-1.8.15.custom.min.js"></script>
		<script type="text/javascript" src="<?=base_url();?>assets/javascript/php.full.min.js"></script>
		<script type="text/javascript" src="<?=base_url();?>assets/javascript/main.js"></script>
		<script type="text/javascript" src="<?=base_url();?>assets/javascript/jrumble.1.1.min.js"></script>
		
		<? if (isset($javascript)) {?>
		<script type="text/javascript" src="<?=base_url();?>assets/javascript/<?=$javascript;?>.js"></script>
		<?}?>
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>assets/css/main.css" />
		<link type="text/css" rel="stylesheet" href="<?=base_url();?>assets/css/jquery_ui_smoothness/jquery-ui-1.8.15.custom.css" />
